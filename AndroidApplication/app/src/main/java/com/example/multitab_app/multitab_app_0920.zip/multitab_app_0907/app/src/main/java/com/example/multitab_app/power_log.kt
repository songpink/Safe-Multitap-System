package com.example.multitab_app

import android.content.DialogInterface
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
import android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
import android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.text.DecimalFormat


class power_log : StandardActivity() {
    var log_period : Int = 0
    lateinit var log_view : TextView
    override fun getExtras(intent: Intent) {
        getExtra_selected_u_id(intent)
        getExtra_id(intent)
        getExtra_session(intent)
    }

    override fun putExtras(intent: Intent) {
        putExtra_selected_u_id(intent)
        putExtra_id(intent)
        putExtra_session(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.power_log)
        getExtras(intent)

        //버튼 뷰 객체 생성
        val usingEnvironment: Button = findViewById(R.id.using_environment)
        val onoffControl: Button = findViewById(R.id.onoff_control)
        val logout: Button = findViewById(R.id.tomain)
        val request_log_button : Button = findViewById(R.id.request_log_button)

        //텍스트 뷰 객체 생성
        log_view = findViewById(R.id.log_text)
        log_view.movementMethod = ScrollingMovementMethod()
        val log_period_view : TextView = findViewById(R.id.log_period_field)

        request_log_button.setOnClickListener{
            // 로그 기간을 설정함.
            try {
                log_period = log_period_view.text.toString().toInt()
                Toast.makeText(applicationContext, "값 : " + log_period.toString(), Toast.LENGTH_SHORT).show()
            }catch(e : NumberFormatException){
                Toast.makeText(applicationContext, "올바른 값을 입력해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 쓰레드를 통해 통신.
            var thread = NetworkThread_request_log()
            thread.start()
        }

        usingEnvironment.setOnClickListener {
            val to_using_environment = Intent(this, using_environment::class.java)
            putExtras(to_using_environment)
            startActivity(to_using_environment)
            overridePendingTransition(0, 0)
            finish()
        }

        onoffControl.setOnClickListener {
            val nextIntent = Intent(this, onoff_control::class.java)
            putExtras(nextIntent)
            startActivity(nextIntent)
            finish()
        }

        logout.setOnClickListener {
            val nextIntent = Intent(this, power_list::class.java)
            putExtras(nextIntent)
            startActivity(nextIntent)
            finish()

        }
    }
    inner class NetworkThread_request_log : NetworkThread(){
        override val loading_dialog: LoadingDialog = LoadingDialog(this@power_log)
        override val target_host: String = PY_HOST
        var log_str : String = ""
        override fun show_loading() {
            runOnUiThread{
                loading_dialog.show()
            }
        }

        override fun delete_loading() {
            runOnUiThread{
                loading_dialog.dismiss()
            }
        }

        override fun do_communication(dis: DataInputStream, dos: DataOutputStream) {
            val log_period_reversed = reverse_int(log_period)
            dos.writeByte(REQUEST_LOG_MESSAGE_TYPE.toInt())
            dos.write(id_array_for_send)
            dos.write(login_token_array_for_send)
            dos.write(selected_u_id_array)
            dos.writeInt(log_period_reversed)

            var type = dis.readByte()
            safe_m_err = dis.readByte()
            val output = ArrayList<Byte>()
            // DB 내의 로그 메시지들을 표현하는 바이트열 받기
            while(true){
                var temp = dis.readByte()
                if(temp != '\u0001'.code.toByte()){
                    output.add(temp)
                }
                else{
                    break
                }
            }
            // 받은 바이트열을 문자열로 변환
            log_str = output.toByteArray().toString(Charsets.UTF_8)
        }

        override fun change_ui() {
            runOnUiThread{
                val nl_log = log_str.replace("\u0000", "\n")
                log_view.text = nl_log
                Toast.makeText(applicationContext, nl_log, Toast.LENGTH_SHORT).show()
            }
        }
    }
}